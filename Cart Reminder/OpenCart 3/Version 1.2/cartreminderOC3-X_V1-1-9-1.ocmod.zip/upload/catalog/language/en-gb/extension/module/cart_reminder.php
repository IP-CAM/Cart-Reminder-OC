<?php
// Heading 
$_['cartreminder_button_value']  = 'Continue on your cart!';