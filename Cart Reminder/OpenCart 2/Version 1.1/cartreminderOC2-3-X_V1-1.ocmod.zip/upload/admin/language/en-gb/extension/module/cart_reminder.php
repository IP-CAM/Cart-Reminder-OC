<?php
// Heading
$_['heading_title']       = 'Cart Reminder v1.1';
 
// Text
$_['text_module']         = 'Modules';
$_['text_edit']           = 'Edit Cart Reminder Module';
$_['text_success']        = 'Success: You have modified the cart reminder module!';
 
// Entry
$_['entry_code']          = 'Cart reminder front page text:';
$_['entry_status']        = 'Status:';

// Error
$_['error_permission']    = 'Warning: You do not have permission to modify module Cart reminder!';
$_['error_code']          = 'Code Required';